﻿using System;

namespace calendar
{
	/// <summary>
	/// RunSession.
	/// </summary>
	public class RunSession
	{
		
		public long Start { get; set;}
		public long Duration { get; set;}
		public long Distance { get; set;}
	}
}