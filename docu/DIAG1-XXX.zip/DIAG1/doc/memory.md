% DIAG1 Memory Project
% Ruben Alonso Gómez, David Coello, Hugo González Labrador
% 14/12/2015

# Project Summary
The application goal is creating a desktop application that records
daily activities like running.
The application should show a calendar with the training sessions to give a quick
feedback to the user about the overall physical activity over a month.
Moreover, the application might keep track of statistics of the previous events.

# Requirements
- Implement a calendar to show the events.
- Create a dialog to insert new activities.
- Show statistics about the activities by day and the overall.

# Integration problems

* One of the team members left in the middle project.
* Code written in Spanish and English
* Refactoring most of the code to keep it simple and follow SOLID principles.
* Learn Git
* Writing and reading from JSON format.
* Different style guides inside the code (numberOfStepsforDay vs numStpsDay)
* Including the logo of our application as an assembler reference was difficult and was left as external dependency.

# Project layout

```
./src/integration
├── Core
│   ├── JSONTransformer.cs
│   ├── Principal.cs
│   ├── RunEventFilter.cs
│   ├── RunSession.cs
│   ├── SessionReadWriter.cs
│   ├── StatController.cs
│   ├── Stats.cs
│   └── Transformer.cs
├── README
├── View
│   ├── AddWindowCore.cs
│   ├── AddWindowView.cs
│   ├── MainWindowCore.cs
│   ├── MainWindowCoreStats.cs
│   ├── MainWindowView.cs
│   ├── MainWindowViewStats.cs
│   └── Principal.cs
├── bin
│   └── Debug
│       ├── Newtonsoft.Json.dll
│       ├── data.json
│       ├── integration.exe
│       ├── integration.exe.mdb
│       └── logo.png
```

# GitHub

To check the latest code run

```
git clone https://github.com/diag1/integration
```

```
2015-12-15 13:59 Hugo Gonzalez Labrador o [master] {origin/master} {origin/HEAD} Build OK
2015-12-15 13:44 Hugo Gonzalez Labrador M─┐ Merge branch 'master' of github.com:diag1/integration
2015-12-10 17:46 dcpulido               │ o añadida documentacion
2015-12-10 17:07 dcpulido               │ o arreglado runrunrun
2015-12-15 13:44 Hugo Gonzalez Labrador o │ Finish
2015-12-10 17:03 dcpulido               o─┘ <v1.0.0> borrado lo que sobra
2015-12-10 10:39 Hugo Gonzalez Labrador o Added interfaces and properties
2015-12-10 10:06 Hugo Gonzalez Labrador o Refactorisation done
2015-12-10 10:02 Hugo Gonzalez Labrador o Added bin
2015-12-03 17:49 Hugo Gonzalez Labrador o TODO(remove sessions)
2015-12-03 16:27 Ruben                  o Merged
2015-11-26 17:28 dcpulido               o [definitivo] {origin/definitivo} problema localizado en getsessiondata
2015-11-26 10:48 Ruben                  o start time added
2015-11-19 20:50 Hugo Gonzalez Labrador o TODO: write to JSON
2015-11-19 20:50 Hugo Gonzalez Labrador o Updated ignored files
2015-11-19 17:36 Hugo Gonzalez Labrador M─┐ Merge branch 'metemeto'
2015-11-19 17:35 dcpulido               │ o [metemeto] {origin/metemeto} view
2015-11-19 17:35 dcpulido               │ o a
2015-11-19 17:34 dcpulido               │ o gitignore
2015-11-19 17:24 Hugo Gonzalez Labrador M─│─┐ Fix conflicts
2015-11-19 17:17 dcpulido               │ o─┘ dialog
2015-11-19 17:20 Hugo Gonzalez Labrador o │ Refactor and join
2015-11-19 10:29 Hugo Gonzalez Labrador o─┘ [dcpulido] {origin/dcpulido} Added treeView to runs
2015-11-17 21:38 dcpulido               o añadida otra tabla
2015-11-17 21:25 dcpulido               o añadiendo tablas
2015-11-17 21:16 dcpulido               o inicio paso a tablas
2015-11-12 21:05 Hugo Gonzalez Labrador o All
2015-11-12 12:06 Hugo Gonzalez Labrador o Fusioned
2015-11-12 09:58 Hugo Gonzalez Labrador o Clean
2015-11-12 09:55 Hugo Gonzalez Labrador o Revert "Initial commit"
2015-11-12 09:45 Hugo Gonzalez Labrador o All together
2015-11-12 09:33 dcpulido               o Readme
2015-11-12 09:29 Hugo González Labrador I Initial commit
```

# Appendix
Check technical manual to see the class diagrams and code structure.


