var namespaces =
[
    [ "calendar", "namespacecalendar.html", null ]
];