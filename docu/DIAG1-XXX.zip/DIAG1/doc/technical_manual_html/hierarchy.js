var hierarchy =
[
    [ "Dialog", null, [
      [ "calendar.AddWindowView", "classcalendar_1_1_add_window_view.html", null ]
    ] ],
    [ "calendar.Principal", "classcalendar_1_1_principal.html", null ],
    [ "calendar.RunEventFilter", "classcalendar_1_1_run_event_filter.html", null ],
    [ "calendar.RunSession", "classcalendar_1_1_run_session.html", null ],
    [ "calendar.SessionReadWriter", "classcalendar_1_1_session_read_writer.html", null ],
    [ "calendar.Stats", "interfacecalendar_1_1_stats.html", [
      [ "calendar.StatController", "classcalendar_1_1_stat_controller.html", null ]
    ] ],
    [ "calendar.Transformer", "interfacecalendar_1_1_transformer.html", [
      [ "calendar.JSONTransformer", "classcalendar_1_1_j_s_o_n_transformer.html", null ]
    ] ],
    [ "Window", null, [
      [ "calendar.MainWindow", "classcalendar_1_1_main_window.html", null ]
    ] ]
];