var dir_f2ee84e8e3a17eaa7015d788fa443c27 =
[
    [ "AddWindowCore.cs", "_add_window_core_8cs.html", [
      [ "AddWindowView", "classcalendar_1_1_add_window_view.html", "classcalendar_1_1_add_window_view" ]
    ] ],
    [ "AddWindowView.cs", "_add_window_view_8cs.html", [
      [ "AddWindowView", "classcalendar_1_1_add_window_view.html", "classcalendar_1_1_add_window_view" ]
    ] ],
    [ "MainWindowCore.cs", "_main_window_core_8cs.html", [
      [ "MainWindow", "classcalendar_1_1_main_window.html", "classcalendar_1_1_main_window" ]
    ] ],
    [ "MainWindowCoreStats.cs", "_main_window_core_stats_8cs.html", null ],
    [ "MainWindowView.cs", "_main_window_view_8cs.html", [
      [ "MainWindow", "classcalendar_1_1_main_window.html", "classcalendar_1_1_main_window" ]
    ] ],
    [ "MainWindowViewStats.cs", "_main_window_view_stats_8cs.html", null ],
    [ "Principal.cs", "_view_2_principal_8cs.html", [
      [ "Principal", "classcalendar_1_1_principal.html", null ]
    ] ]
];