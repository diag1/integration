var interfacecalendar_1_1_stats =
[
    [ "getDistDay", "interfacecalendar_1_1_stats.html#a67e7c9519d539cfe383b4024324bd655", null ],
    [ "getDistTot", "interfacecalendar_1_1_stats.html#a914330b12fe383ab98d85f3da9c0da83", null ],
    [ "getNumHourDay", "interfacecalendar_1_1_stats.html#a30b128d73be7491336691b604d99577d", null ],
    [ "getNumHourTot", "interfacecalendar_1_1_stats.html#a81e7a9ef7d00966eff314b6066294cbc", null ],
    [ "getNumStpsDay", "interfacecalendar_1_1_stats.html#aaa6525dac9b427a9167a2afbccd15aee", null ],
    [ "getNumStpsTot", "interfacecalendar_1_1_stats.html#ae3356e2c5c58fe007a50e1d147245cc8", null ],
    [ "getVelMedDay", "interfacecalendar_1_1_stats.html#ac442b40a4b0f509e26b00d1f27f06bb2", null ],
    [ "getVelMedTot", "interfacecalendar_1_1_stats.html#a7fa0eba98303cb3f63247074fb1e6b8c", null ]
];