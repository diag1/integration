var classcalendar_1_1_stat_controller =
[
    [ "StatController", "classcalendar_1_1_stat_controller.html#a6acdc4b0ef7625898580d14feaab6f32", null ],
    [ "getDistDay", "classcalendar_1_1_stat_controller.html#a9221fdd7b56daf3783eaee73b29f2626", null ],
    [ "getDistTot", "classcalendar_1_1_stat_controller.html#ad81b460a6eb2f075c710af8c3afa59ab", null ],
    [ "getNumHourDay", "classcalendar_1_1_stat_controller.html#a1d7858696bbdaf66a50f778530c68e69", null ],
    [ "getNumHourTot", "classcalendar_1_1_stat_controller.html#a7100c77d91e087f461492c6ef752d43b", null ],
    [ "getNumStpsDay", "classcalendar_1_1_stat_controller.html#adc856e48c212902751c54789eeb71e17", null ],
    [ "getNumStpsTot", "classcalendar_1_1_stat_controller.html#a3a0298fa1400b2d96c9ddd5f2e2c1ca9", null ],
    [ "getVelMedDay", "classcalendar_1_1_stat_controller.html#a8d726df2e6798c0802cbcc0e8e8ce9e8", null ],
    [ "getVelMedTot", "classcalendar_1_1_stat_controller.html#a7380aebad0d2ac3fbedf5835b66171df", null ]
];