var searchData=
[
  ['addwindowcore_2ecs',['AddWindowCore.cs',['../_add_window_core_8cs.html',1,'']]],
  ['addwindowview_2ecs',['AddWindowView.cs',['../_add_window_view_8cs.html',1,'']]]
];
