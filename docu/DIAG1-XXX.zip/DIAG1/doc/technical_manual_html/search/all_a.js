var searchData=
[
  ['tojson',['ToJson',['../classcalendar_1_1_session_read_writer.html#afc65b3582d692e5a9a74639fcec35207',1,'calendar::SessionReadWriter']]],
  ['transformer',['Transformer',['../interfacecalendar_1_1_transformer.html',1,'calendar']]],
  ['transformer_2ecs',['Transformer.cs',['../_transformer_8cs.html',1,'']]]
];
