var searchData=
[
  ['distance',['Distance',['../classcalendar_1_1_run_session.html#a70bb90218df1bdb2ecda13f8b7da467e',1,'calendar::RunSession']]],
  ['duration',['Duration',['../classcalendar_1_1_run_session.html#a69deaa6af29074544fada6664b90d10b',1,'calendar::RunSession']]]
];
