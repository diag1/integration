var searchData=
[
  ['principal_2ecs',['Principal.cs',['../_core_2_principal_8cs.html',1,'']]],
  ['principal_2ecs',['Principal.cs',['../_view_2_principal_8cs.html',1,'']]]
];
