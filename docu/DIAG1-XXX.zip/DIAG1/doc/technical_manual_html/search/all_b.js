var searchData=
[
  ['writetodataformat',['WriteToDataFormat',['../classcalendar_1_1_j_s_o_n_transformer.html#ab3fa1c97ed1e7f14bfa5ff995e02abd6',1,'calendar.JSONTransformer.WriteToDataFormat()'],['../interfacecalendar_1_1_transformer.html#a6fed4de59ef71de62d6e43f789d7b44e',1,'calendar.Transformer.WriteToDataFormat()']]]
];
