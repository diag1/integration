var searchData=
[
  ['jsontransformer',['JSONTransformer',['../classcalendar_1_1_j_s_o_n_transformer.html#a1226acb32c6e2659dc1b17b3126a6b09',1,'calendar::JSONTransformer']]]
];
